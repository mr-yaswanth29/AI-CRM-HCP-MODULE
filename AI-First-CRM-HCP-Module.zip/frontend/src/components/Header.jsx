import React from "react";
const Header = () => <h1>AI-First CRM – HCP Module</h1>;
export default Header;
