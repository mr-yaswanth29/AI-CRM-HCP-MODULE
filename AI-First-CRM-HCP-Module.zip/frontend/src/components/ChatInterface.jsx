import React from "react";
const ChatInterface = () => (
  <div>
    <h2>AI Chat</h2>
    <textarea placeholder="Type here..." />
    <button>Send</button>
  </div>
);
export default ChatInterface;
