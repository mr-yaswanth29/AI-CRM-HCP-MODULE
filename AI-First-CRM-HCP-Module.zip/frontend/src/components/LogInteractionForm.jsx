import React from "react";
const LogInteractionForm = () => (
  <div>
    <h2>Log Interaction</h2>
    <input placeholder="HCP Name" />
    <textarea placeholder="Discussion" />
    <button>Submit</button>
  </div>
);
export default LogInteractionForm;
