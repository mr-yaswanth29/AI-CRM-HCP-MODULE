def log_interaction_tool(text):
    return {"summary": text, "sentiment": "Positive"}
