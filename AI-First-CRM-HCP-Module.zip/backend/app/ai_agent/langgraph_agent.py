from app.ai_agent.tools import log_interaction_tool

def run_agent(text):
    return log_interaction_tool(text)
